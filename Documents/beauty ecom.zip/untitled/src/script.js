// GlowShop Ecommerce JS

document.addEventListener('DOMContentLoaded', () => {
  const cartButton = document.querySelector('#cartButton');
  const cartPanel = document.querySelector('.cart-panel');
  const addToCartButtons = document.querySelectorAll('.add-to-cart');
  const cartItemsContainer = document.querySelector('.cart-items');
  const checkoutButton = document.querySelector('#checkoutButton');

  const loginButton = document.querySelector('#loginButton');
  const signupButton = document.querySelector('#signupButton');
  const loginModal = document.querySelector('#loginModal');
  const signupModal = document.querySelector('#signupModal');
  const modalBackdrops = document.querySelectorAll('.modal-backdrop');

  let cart = [];

  function toggleCart() {
    cartPanel.classList.toggle('show');
  }

  function renderCart() {
    cartItemsContainer.innerHTML = '';
    if (cart.length === 0) {
      cartItemsContainer.innerHTML = '<p class="small muted">Your cart is empty.</p>';
      return;
    }
    cart.forEach((item, i) => {
      const div = document.createElement('div');
      div.classList.add('cart-item');
      div.innerHTML = `
        <div style="flex:1">
          <strong>${item.name}</strong><br>
          <span class="small">$${item.price}</span>
        </div>
        <button class="remove small" data-index="${i}">✖</button>
      `;
      cartItemsContainer.appendChild(div);
    });
  }

  addToCartButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      const name = e.target.dataset.name;
      const price = parseFloat(e.target.dataset.price);
      cart.push({ name, price });
      renderCart();
      cartPanel.classList.add('show');
    });
  });

  cartPanel.addEventListener('click', (e) => {
    if (e.target.classList.contains('remove')) {
      const i = parseInt(e.target.dataset.index);
      cart.splice(i, 1);
      renderCart();
    }
  });

  checkoutButton.addEventListener('click', async () => {
    if (cart.length === 0) return alert('Cart is empty.');
    const res = await fetch('/api/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: cart })
    });
    if (res.ok) {
      alert('Checkout successful!');
      cart = [];
      renderCart();
      toggleCart();
    } else {
      alert('Checkout failed.');
    }
  });

  cartButton.addEventListener('click', toggleCart);

  // Modal logic
  function showModal(modal) {
    modal.classList.add('show');
  }

  function hideModals() {
    modalBackdrops.forEach(m => m.classList.remove('show'));
  }

  loginButton?.addEventListener('click', () => showModal(loginModal));
  signupButton?.addEventListener('click', () => showModal(signupModal));

  modalBackdrops.forEach(m => {
    m.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal-backdrop')) {
        hideModals();
      }
    });
  });

  // Auth forms
  const loginForm = document.querySelector('#loginForm');
  const signupForm = document.querySelector('#signupForm');

  loginForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(loginForm);
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(Object.fromEntries(formData)),
      headers: { 'Content-Type': 'application/json' }
    });
    if (res.ok) {
      alert('Login successful!');
      hideModals();
    } else {
      alert('Login failed!');
    }
  });

  signupForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(signupForm);
    const res = await fetch('/api/auth/signup', {
      method: 'POST',
      body: JSON.stringify(Object.fromEntries(formData)),
      headers: { 'Content-Type': 'application/json' }
    });
    if (res.ok) {
      alert('Signup successful! You can now log in.');
      hideModals();
    } else {
      alert('Signup failed!');
    }
  });
});
